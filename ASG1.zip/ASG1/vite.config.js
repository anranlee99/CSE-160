export default {
    // eslint-disable-next-line no-undef
    base: process.env.REPO_NAME || "/repo-name/",
  };